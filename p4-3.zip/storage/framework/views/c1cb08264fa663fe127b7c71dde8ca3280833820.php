<?php $__env->startSection('title'); ?>
    <?php echo e('Welcome'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('head'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1><?php echo e('Contact Page'); ?></h1>

        <p>
            Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add
            your own fullscreen background photo to make it your own.
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>