@extends('master')

@section('title')
    {{ 'Welcome' }}
@endsection

@push('head')

@endpush

@section('content')
    <div class="text-center">
        <h1>{{ 'Contact Page' }}</h1>

        <p>
            Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add
            your own fullscreen background photo to make it your own.
        </p>
    </div>
@endsection